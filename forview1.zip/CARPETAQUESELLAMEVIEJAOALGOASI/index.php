<!DOCTYPE html>
<html lang="en">
<?php
include('includes/head.php');
?>

<body>
    <div class="content-wrapper">
        <?php
         include('includes/header.php');
         include('modules/index.php');
         include('includes/footer.php');
        ?>
    </div>
    <?php
        include('includes/scripts.php');
    ?>
</body>

</html>