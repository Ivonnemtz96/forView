<!-- Lines -->
<div class="content-lines-wrapper">
    <div class="content-lines-inner">
        <div class="content-lines"></div>
    </div>
</div>
<!-- Navbar -->
<div class="duru-header header-transparent">
    <div class="container">
        <div class="duru-header-container">
            <!-- Logo -->
            <div class="logo" data-mobile-logo="images/logo.png" data-sticky-logo="images/logo.png">
                <a href="index.php"><img src="images/logo-white.png" alt=""></a>
            </div>
            <!-- Burger menu -->
            <div class="burger-menu">
                <div class="line-menu line-half first-line"></div>
                <div class="line-menu"></div>
                <div class="line-menu line-half last-line"></div>
            </div>
            <!--Navigation menu -->
            <nav class="duru-menu menu-caret">
                <ul>
                    <!-- <li class="current-menu"><a href="index.php">Inicio</a>
                        <ul>
                            <li class="current-menu"><a href="index.html">Home Layout 01</a></li>
                            <li><a href="index2.html">Home Layout 02</a></li>
                            <li><a href="index3.html">Home Layout 03</a></li>
                            <li><a href="index4.html">Home Layout 04</a></li>
                            <li><a href="index5.html">Home Layout 05</a></li>
                            <li><a href="index6.html">Home Layout 06</a></li>
                            <li><a href="index7.html">Home Layout 07</a></li>
                            <li><a href="index8.html">Home Layout 08</a></li>
                            <li><a href="index9.html">Home Layout 09</a></li>
                        </ul>
                    </li> -->
                    <li class="current-menu"><a href="productos.php">Productos</a>
                        <ul>
                            <li class="current-menu"><a href="detalle.php">Corredera</a></li>
                            <li><a href="detalle.php">Pivotante</a></li>
                            <li><a href="detalle.php">Guillotina</a></li>
                            <li><a href="detalle.php">Turnable Corner</a></li>
                        </ul>
                    </li>
                    <li><a href="galeria.php">Galería</a></li>
                    <li><a href="empresa.php">Empresa</a></li>
                    <li><a href="distribuidor.php">Distribuidor</a></li>
                    <li><a href="descarga.php">Descarga</a></li>
                    <!-- <li><a href="#">Projects</a>
                        <ul>
                            <li><a href="projects.html">Projects 01</a></li>
                            <li><a href="projects2.html">Projects 02</a></li>
                            <li><a href="projects3.html">Projects 03</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Pages</a>
                        <ul>
                            <li><a href="gallery.html">Gallery</a></li>
                            <li><a href="faq.html">Faqs</a></li>
                            <li><a href="process.html">Process</a></li>
                            <li><a href="404.html">404 Page</a></li>
                            <li><a href="#">Other Pages</a>
                                <ul>
                                    <li><a href="services-page.html">Services Page</a></li>
                                    <li><a href="project-page.html">Project Page</a></li>
                                    <li><a href="post.html">Post Page</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#">Blog</a>
                        <ul>
                            <li><a href="blog.html">Blog 01</a></li>
                            <li><a href="blog2.html">Blog 02</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.html">Contact Us</a></li> -->
                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- Slider -->